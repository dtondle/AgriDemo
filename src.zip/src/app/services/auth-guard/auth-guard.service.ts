import { Injectable } from '@angular/core';
import { CanActivate, CanLoad, Route, ActivatedRouteSnapshot, Router } from '@angular/router';
import { User } from '../../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard { // implements CanLoad, CanActivate
  userData: any;
  user: User;
  validUser: boolean;
  selectedUser: any;
  constructor() {
    this.user = {
      name: '',
      username: '',
      password: ''
    };
    this.validUser = false;
  }

  // async canActivate(): Promise<boolean> {
  //  // return await this.checkLogin();
  // }

  // async canLoad(): Promise<boolean> {
  //  // return await this.checkLogin();
  // }

  // async checkLogin(): Promise<boolean> {
  //   try {
  //     console.log(`*** Auth : Guard : Activated.`);
  //     // if we have dms token, we can pass the guard
  //     if (token) {
  //       console.log(`*** Auth : Guard : Found DMS token.`);
  //       // only make profile call if we don't already have profile
  //       //   TODO: evaluate whether profile should just be cached
  //       if (!this.sessionService.userProfile) {
  //         console.log(`*** Auth : Guard : Profile not found, fetching profile...`);
  //         await this.sessionService.getProfile();
  //       }

  //       console.log(`*** Auth : Guard : Pass guard.`);
  //       return Promise.resolve(true);
  //     }

  //     console.log(`*** Auth : Guard : Did not find DMS token, try to login user.`);

  //     // dms token not found, attempt to login
  //     await this.sessionService.login();

  //     console.log(`*** Auth : Guard : Logged in, try to get profile.`);

  //     // successful login, now get profile
  //     await this.sessionService.getProfile();
  //     console.log(`*** Auth : Guard : Pass guard.`);
  //     return Promise.resolve(true);
  //   } catch {
  //     console.log(`*** Auth : Guard : Fail guard.`);
  //     return Promise.resolve(false);
  //   }
  // }

  public login(userObj: User): boolean {
    console.log('User login');
    const uData = this.getProfile();
    let counter = 0;
    if (this.userData.length > 0) {
      for (let i = 0; i < this.userData.length; i++) {
        if (uData[i].username === userObj.username) {
          if (uData[i].password === userObj.password) {
            counter++;
          }
        }
      }
      if (counter === 1) {
        return true;
      } else {
        return false;
      }
    }
  }

  public getProfile() {
    console.log('Get User Profiles');
    if (localStorage.getItem('Users')) {
      this.userData = JSON.parse(localStorage.getItem('Users'));
    } else {
      this.userData = [];
    }
    return this.userData;
  }

  public isDuplicateFilter(userObj: any): boolean {
    let isDuplicate = false;
    const uData = this.getProfile();
    if (uData.length > 0) {
      for (let i = 0; i < this.userData.length; i++) {
        if (uData[i].username === userObj.username) {
          isDuplicate = true;
        }
      }
    }
    return isDuplicate;
  }

  public registerUser(userObj: any): boolean {
    console.log('User register');
    const isDuplicateUser = this.isDuplicateFilter(userObj);
    if (isDuplicateUser) {
      return true;
    }
    else {
      this.user.name = userObj.name;
      this.user.username = userObj.username;
      this.user.password = userObj.password;
      this.userData.push(this.user);
      localStorage.setItem('Users', JSON.stringify(this.userData));
      return false;
    }
  }

  public logout() {
    console.log('User logout');
    return true;
  }
}
