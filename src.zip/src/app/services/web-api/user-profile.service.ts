import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserProfileURIs } from '../web-api/users-uri';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {
  selectedProfile: string;
  constructor(private http: HttpClient) { }

  getUsers(userinfo: any) {
    const uri = UserProfileURIs.UserList + '=' + userinfo;
    return this.http.get(uri);
  }

  getUserProfile(userprofile) {
    return this.http.get(UserProfileURIs.UserProfile + '/' + userprofile);
  }
}
