// List of resources supported by User Profile Web API
export class UserProfileURIs {
    public static readonly UserList = 'https://api.github.com/search/users?q';
    public static readonly UserProfile = 'https://api.github.com/users';
}
