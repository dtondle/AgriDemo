export class User {
    public name: string;
    public username: string;
    public password: string;
}