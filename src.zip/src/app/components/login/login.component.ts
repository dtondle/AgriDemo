import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    username: new FormControl(''),
    password: new FormControl('')
  });
  user: any;
  message: string; // Notification message
  alertVisibility: boolean; // Alert visibility status
  alertClassValue: boolean; // Alert class toggle
  constructor(private route: Router, private authService: AuthGuard) {
    this.message = '';
    this.alertVisibility = false;
  }

  ngOnInit() {
  }

  onLogin() {
    console.log(this.loginForm.value);
    this.user = this.loginForm.value;
    const response = this.authService.login(this.user);
    if (response) {
      const usersData: Array<any> = this.authService.getProfile();
      const currentUser: any = usersData.filter((item, index) => {
        return item.username === this.user.username;
      });
      localStorage.setItem('current-user', JSON.stringify(currentUser));
      this.route.navigate(['/home']);
    } else {
      this.message = 'Invalid Credential';
      this.alertClassValue = true;
      this.alertVisibility = true;
    }

  }

}
