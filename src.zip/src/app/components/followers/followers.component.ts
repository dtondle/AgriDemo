import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {

  currentUser: string;
  public barChartData = [{
    id: 0, // number
    label: 'label name2',  // string
    value: 10 // number
  }, {
    id: 1, // number
    label: 'label name1',  // string
    value: 15
  }];
  constructor() { }

  ngOnInit() {
    if (localStorage.getItem('current-user')) {
      this.currentUser = JSON.parse(localStorage.getItem('current-user'));
    }
  }

}
