import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  currentUser: string;
  Users: any;
  constructor(private authService: AuthGuard, private router: Router) { }

  ngOnInit() {
    if (localStorage.getItem('current-user')) {
      this.currentUser = JSON.parse(localStorage.getItem('current-user'));
    }
    this.getUsersData();
  }

  public getUsersData() {
    this.Users = this.authService.getProfile();
  }

  public viewProfile(user) {
    const response = this.authService.selectedProfileData(user);
    if (response) {
      this.router.navigate(['/user-profile']);
    } else {
      alert('Error in User Profile');
    }
  }

}
