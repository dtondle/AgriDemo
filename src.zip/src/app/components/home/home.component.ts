import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';
import { UserProfileService } from '../../services/web-api/user-profile.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  currentUser: string;
  inputData: string;
  Users: any;
  totalCount: number;
  dataMessage: string;
  dataFlag: boolean;
  constructor(private authService: AuthGuard,
    private router: Router,
    private userService: UserProfileService) {
    this.inputData = '';
    this.totalCount = 0;
    this.dataFlag = true;
    this.dataMessage = 'No Data';
  }

  ngOnInit() {
    if (localStorage.getItem('current-user')) {
      this.currentUser = JSON.parse(localStorage.getItem('current-user'));
    }
  }

  public searchUsers(input) {
    this.dataFlag = true;
    if (input.trim() !== '') {
      this.dataMessage = 'Loading Data ....'
      this.userService.getUsers(input)
        .subscribe((data) => {
          if (data['items'].length > 0) {
            this.dataFlag = false;
            this.Users = data['items'];
          } else {
            this.dataMessage = 'No Data Found';
          }
          this.totalCount = data['total_count'];
        });
    } else {
      this.dataMessage = 'Please Enter Some value in search box!!!!';
    }
  }

  public viewProfile(user) {
    if (user) {
      this.userService.selectedProfile = user.login;
      this.router.navigate(['/user-profile']);
    }
  }

}
