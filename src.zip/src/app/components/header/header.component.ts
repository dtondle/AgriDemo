import { Component, OnInit, ViewEncapsulation, Input, OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  @Input() uname: any;
  username: string;
  constructor(private authService: AuthGuard, private router: Router) { }

  ngOnInit() {
    this.username = this.uname[0].name;
  }

  public signOut() {
    const response = this.authService.logout();
    if (response) {
      localStorage.removeItem('current-user');
      this.router.navigate(['/login']);
    }
  }

}
