import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  // Register Form model
  registerForm = new FormGroup({
    name: new FormControl(''),
    username: new FormControl(''),
    password: new FormControl(''),
    cnfPassword: new FormControl('')
  });
  user: any; // user model
  message: string; // Notification message
  alertVisibility: boolean; // Alert visibility status
  alertClassValue: boolean; // Alert class toggle
  constructor(private authService: AuthGuard) {
    this.message = '';
    this.alertVisibility = false;
  }

  ngOnInit() {
  }

  // Register user click
  registerUser() {
    this.user = this.registerForm.value;
    if (this.user.password === this.user.cnfPassword) {
      const response = this.authService.registerUser(this.user);
      if (response) {
        this.message = 'Username already exist';
        this.alertClassValue = true;
      } else {
        this.message = 'User Registered Successfully';
        this.alertClassValue = false;
        this.registerForm.reset();
      }
    } else {
      this.message = 'Password is not matched';
      this.alertClassValue = true;
    }
    this.alertVisibility = true;
  }
}
