import { Component, OnInit } from '@angular/core';
import { UserProfileService } from '../../services/web-api/user-profile.service';
import { AuthGuard } from '../../services/auth-guard/auth-guard.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  currentUser: string;
  selectedUserInfo: any;
  constructor(private authService: AuthGuard,
    private userService: UserProfileService) {
    this.selectedUserInfo = {
      name: '',
      login: '',
      followers: '',
      following: '',
      avatar_url: '',
      blog: '',
      events_url: '',
      organizations_url: '',
      location: ''
    }
  }

  ngOnInit() {
    if (localStorage.getItem('current-user')) {
      this.currentUser = JSON.parse(localStorage.getItem('current-user'));
    }
    this.getUserInformation();
  }

  public getUserInformation() {
    const selectedUser = this.userService.selectedProfile;
    this.userService.getUserProfile(selectedUser)
      .subscribe((data) => {
        this.selectedUserInfo = data;
      });
  }

}
